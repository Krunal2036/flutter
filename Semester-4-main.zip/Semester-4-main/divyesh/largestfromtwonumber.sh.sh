echo "enter number : "
read n1
echo "enter number : "
read n2
if [ $n1 -gt $n2 ] 
then
echo $n1
else
echo $n2
fi