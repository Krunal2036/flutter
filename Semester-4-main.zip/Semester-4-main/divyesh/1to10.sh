i=1
while [ $i -le 10 ] 
do
    echo -n $i" "
    i=`expr $i + 1`
done