import 'dart:io';
import 'user.dart';
void main(List<String> args) {
  User user = User();
}